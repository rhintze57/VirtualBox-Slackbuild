#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 7
#define VBOX_VERSION_MINOR 2
#define VBOX_VERSION_BUILD 20
#define VBOX_VERSION_STRING_RAW "7.2.20"
#define VBOX_VERSION_STRING "7.2.20"
#define VBOX_API_VERSION_STRING "7_2"

#define VBOX_PRIVATE_BUILD_DESC "Private build by root"

#endif
